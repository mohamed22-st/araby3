// أنواع البيانات للمستخدمين والمحتوى التعليمي

export interface User {
  id: number;
  username: string;
  email: string;
  password: string;
  role: 'admin' | 'student';
  created_at: string;
  updated_at: string;
}

export interface Grade {
  id: number;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
}

export interface Subject {
  id: number;
  name: string;
  description: string | null;
  grade_id: number;
  created_at: string;
  updated_at: string;
}

export interface Lesson {
  id: number;
  title: string;
  description: string | null;
  video_url: string | null;
  subject_id: number;
  created_at: string;
  updated_at: string;
}

export interface Quiz {
  id: number;
  title: string;
  description: string | null;
  lesson_id: number;
  created_at: string;
  updated_at: string;
}

export interface QuizQuestion {
  id: number;
  quiz_id: number;
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: 'a' | 'b' | 'c' | 'd';
  created_at: string;
  updated_at: string;
}

export interface Subscription {
  id: number;
  user_id: number;
  start_date: string;
  end_date: string | null;
  status: 'active' | 'expired' | 'cancelled';
  created_at: string;
  updated_at: string;
}

export interface StudentProgress {
  id: number;
  user_id: number;
  lesson_id: number;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface QuizResult {
  id: number;
  user_id: number;
  quiz_id: number;
  score: number;
  created_at: string;
  updated_at: string;
}
