import { D1Database } from '@cloudflare/workers-types';

export async function getCloudflareContext() {
  // @ts-ignore
  return process.env.CLOUDFLARE_CONTEXT || {};
}

export async function getDB(): Promise<D1Database> {
  const { env } = await getCloudflareContext();
  return env?.DB;
}

// وظائف المستخدمين
export async function getUserByUsername(username: string) {
  const db = await getDB();
  return db.prepare('SELECT * FROM users WHERE username = ?').bind(username).first();
}

export async function getUserByEmail(email: string) {
  const db = await getDB();
  return db.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
}

export async function getUserById(id: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
}

export async function createUser(username: string, email: string, password: string, role: 'admin' | 'student') {
  const db = await getDB();
  return db.prepare('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?) RETURNING *')
    .bind(username, email, password, role)
    .first();
}

export async function countStudents() {
  const db = await getDB();
  return db.prepare('SELECT COUNT(*) as count FROM users WHERE role = ?').bind('student').first();
}

// وظائف الصفوف الدراسية
export async function getAllGrades() {
  const db = await getDB();
  return db.prepare('SELECT * FROM grades ORDER BY id').all();
}

export async function getGradeById(id: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM grades WHERE id = ?').bind(id).first();
}

// وظائف المواضيع
export async function getSubjectsByGradeId(gradeId: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM subjects WHERE grade_id = ? ORDER BY id').bind(gradeId).all();
}

export async function getSubjectById(id: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM subjects WHERE id = ?').bind(id).first();
}

export async function createSubject(name: string, description: string | null, gradeId: number) {
  const db = await getDB();
  return db.prepare('INSERT INTO subjects (name, description, grade_id) VALUES (?, ?, ?) RETURNING *')
    .bind(name, description, gradeId)
    .first();
}

// وظائف الدروس
export async function getLessonsBySubjectId(subjectId: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM lessons WHERE subject_id = ? ORDER BY id').bind(subjectId).all();
}

export async function getLessonById(id: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM lessons WHERE id = ?').bind(id).first();
}

export async function createLesson(title: string, description: string | null, videoUrl: string | null, subjectId: number) {
  const db = await getDB();
  return db.prepare('INSERT INTO lessons (title, description, video_url, subject_id) VALUES (?, ?, ?, ?) RETURNING *')
    .bind(title, description, videoUrl, subjectId)
    .first();
}

export async function updateLesson(id: number, title: string, description: string | null, videoUrl: string | null) {
  const db = await getDB();
  return db.prepare('UPDATE lessons SET title = ?, description = ?, video_url = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? RETURNING *')
    .bind(title, description, videoUrl, id)
    .first();
}

// وظائف الاختبارات
export async function getQuizzesByLessonId(lessonId: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM quizzes WHERE lesson_id = ? ORDER BY id').bind(lessonId).all();
}

export async function getQuizById(id: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM quizzes WHERE id = ?').bind(id).first();
}

export async function createQuiz(title: string, description: string | null, lessonId: number) {
  const db = await getDB();
  return db.prepare('INSERT INTO quizzes (title, description, lesson_id) VALUES (?, ?, ?) RETURNING *')
    .bind(title, description, lessonId)
    .first();
}

// وظائف أسئلة الاختبارات
export async function getQuestionsByQuizId(quizId: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY id').bind(quizId).all();
}

export async function createQuizQuestion(
  quizId: number, 
  question: string, 
  optionA: string, 
  optionB: string, 
  optionC: string, 
  optionD: string, 
  correctAnswer: 'a' | 'b' | 'c' | 'd'
) {
  const db = await getDB();
  return db.prepare(
    'INSERT INTO quiz_questions (quiz_id, question, option_a, option_b, option_c, option_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING *'
  ).bind(quizId, question, optionA, optionB, optionC, optionD, correctAnswer).first();
}

// وظائف الاشتراكات
export async function getSubscriptionByUserId(userId: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM subscriptions WHERE user_id = ? ORDER BY id DESC LIMIT 1').bind(userId).first();
}

export async function createSubscription(userId: number, endDate: string, status: 'active' | 'expired' | 'cancelled') {
  const db = await getDB();
  return db.prepare('INSERT INTO subscriptions (user_id, end_date, status) VALUES (?, ?, ?) RETURNING *')
    .bind(userId, endDate, status)
    .first();
}

export async function updateSubscriptionStatus(id: number, status: 'active' | 'expired' | 'cancelled') {
  const db = await getDB();
  return db.prepare('UPDATE subscriptions SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? RETURNING *')
    .bind(status, id)
    .first();
}

// وظائف تقدم الطلاب
export async function getStudentProgressByUserId(userId: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM student_progress WHERE user_id = ?').bind(userId).all();
}

export async function markLessonAsCompleted(userId: number, lessonId: number) {
  const db = await getDB();
  // التحقق من وجود سجل
  const existing = await db.prepare('SELECT * FROM student_progress WHERE user_id = ? AND lesson_id = ?')
    .bind(userId, lessonId)
    .first();
  
  if (existing) {
    return db.prepare('UPDATE student_progress SET completed = TRUE, updated_at = CURRENT_TIMESTAMP WHERE user_id = ? AND lesson_id = ? RETURNING *')
      .bind(userId, lessonId)
      .first();
  } else {
    return db.prepare('INSERT INTO student_progress (user_id, lesson_id, completed) VALUES (?, ?, TRUE) RETURNING *')
      .bind(userId, lessonId)
      .first();
  }
}

// وظائف نتائج الاختبارات
export async function saveQuizResult(userId: number, quizId: number, score: number) {
  const db = await getDB();
  return db.prepare('INSERT INTO quiz_results (user_id, quiz_id, score) VALUES (?, ?, ?) RETURNING *')
    .bind(userId, quizId, score)
    .first();
}

export async function getQuizResultsByUserId(userId: number) {
  const db = await getDB();
  return db.prepare('SELECT * FROM quiz_results WHERE user_id = ?').bind(userId).all();
}
