import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import * as bcrypt from 'bcryptjs';
import * as db from './db';

// مدة صلاحية الجلسة (7 أيام)
const SESSION_EXPIRY = 7 * 24 * 60 * 60 * 1000;

// إنشاء جلسة جديدة
export async function createSession(userId: number, role: 'admin' | 'student') {
  const sessionId = crypto.randomUUID();
  const expires = new Date(Date.now() + SESSION_EXPIRY);
  
  // حفظ معلومات الجلسة في ملفات تعريف الارتباط
  cookies().set({
    name: 'session_id',
    value: sessionId,
    httpOnly: true,
    expires,
    path: '/',
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
  });
  
  cookies().set({
    name: 'user_id',
    value: userId.toString(),
    httpOnly: true,
    expires,
    path: '/',
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
  });
  
  cookies().set({
    name: 'user_role',
    value: role,
    httpOnly: true,
    expires,
    path: '/',
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
  });
  
  return { sessionId, userId, role, expires };
}

// التحقق من صحة الجلسة الحالية
export async function validateSession() {
  const sessionId = cookies().get('session_id')?.value;
  const userId = cookies().get('user_id')?.value;
  const role = cookies().get('user_role')?.value as 'admin' | 'student' | undefined;
  
  if (!sessionId || !userId || !role) {
    return null;
  }
  
  // التحقق من وجود المستخدم في قاعدة البيانات
  const user = await db.getUserById(parseInt(userId));
  if (!user || user.role !== role) {
    return null;
  }
  
  return { userId: parseInt(userId), role, user };
}

// إنهاء الجلسة الحالية
export function endSession() {
  cookies().delete('session_id');
  cookies().delete('user_id');
  cookies().delete('user_role');
}

// التحقق من كلمة المرور
export async function verifyPassword(plainPassword: string, hashedPassword: string) {
  return bcrypt.compare(plainPassword, hashedPassword);
}

// تشفير كلمة المرور
export async function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

// التحقق من تسجيل الدخول للمسؤول
export async function requireAdmin() {
  const session = await validateSession();
  if (!session || session.role !== 'admin') {
    redirect('/login?error=unauthorized');
  }
  return session;
}

// التحقق من تسجيل الدخول للطالب
export async function requireStudent() {
  const session = await validateSession();
  if (!session || session.role !== 'student') {
    redirect('/login?error=unauthorized');
  }
  return session;
}

// التحقق من تسجيل الدخول لأي مستخدم
export async function requireAuth() {
  const session = await validateSession();
  if (!session) {
    redirect('/login');
  }
  return session;
}

// التحقق من عدم تسجيل الدخول
export async function requireGuest() {
  const session = await validateSession();
  if (session) {
    redirect(session.role === 'admin' ? '/admin' : '/dashboard');
  }
}
