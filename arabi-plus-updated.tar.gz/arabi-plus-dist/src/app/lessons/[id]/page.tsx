import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireStudent } from "@/lib/auth";
import * as db from "@/lib/db";
import Link from "next/link";

export default async function LessonPage({ params }: { params: { id: string } }) {
  // التحقق من صلاحيات الطالب
  const session = await requireStudent();
  
  // جلب بيانات الدرس
  const lessonId = parseInt(params.id);
  const lesson = await db.getLessonById(lessonId);
  
  if (!lesson) {
    return (
      <div className="container mx-auto p-6 text-center">
        <h1 className="text-3xl font-bold mb-4">الدرس غير موجود</h1>
        <p className="mb-6">لم يتم العثور على الدرس المطلوب</p>
        <Link href="/dashboard">
          <Button>العودة إلى لوحة التحكم</Button>
        </Link>
      </div>
    );
  }
  
  // جلب بيانات الموضوع
  const subject = await db.getSubjectById(lesson.subject_id);
  
  // جلب الاختبارات المرتبطة بالدرس
  const quizzesResult = await db.getQuizzesByLessonId(lessonId);
  const quizzes = quizzesResult?.results || [];
  
  // تحديث تقدم الطالب
  await db.markLessonAsCompleted(session.userId, lessonId);

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">{lesson.title}</h1>
          <p className="text-gray-600">{lesson.description || 'لا يوجد وصف متاح'}</p>
          {subject && (
            <p className="text-primary mt-1">
              <Link href={`/subjects/${subject.id}`} className="hover:underline">
                {subject.name}
              </Link>
            </p>
          )}
        </div>
        <div className="flex gap-4">
          <Link href={`/subjects/${lesson.subject_id}`}>
            <Button variant="outline">العودة للموضوع</Button>
          </Link>
        </div>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>فيديو الدرس</CardTitle>
        </CardHeader>
        <CardContent>
          {lesson.video_url ? (
            <div className="aspect-video bg-black rounded-md overflow-hidden">
              <video 
                src={lesson.video_url} 
                controls 
                className="w-full h-full"
                poster="/video-placeholder.jpg"
              >
                متصفحك لا يدعم تشغيل الفيديو
              </video>
            </div>
          ) : (
            <div className="aspect-video bg-gray-100 rounded-md flex items-center justify-center">
              <p className="text-gray-500">الفيديو غير متاح حاليًا</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>اختبارات الدرس</CardTitle>
        </CardHeader>
        <CardContent>
          {quizzes.length === 0 ? (
            <p className="text-center text-muted-foreground">لا توجد اختبارات متاحة لهذا الدرس</p>
          ) : (
            <div className="space-y-4">
              {quizzes.map((quiz) => (
                <Link key={quiz.id} href={`/quizzes/${quiz.id}`}>
                  <Button variant="outline" className="w-full justify-start">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                    <span>{quiz.title}</span>
                  </Button>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
