import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { requireStudent } from "@/lib/auth";
import * as db from "@/lib/db";
import Link from "next/link";

export default async function SubscriptionPage() {
  // التحقق من صلاحيات الطالب
  const session = await requireStudent();
  
  // جلب بيانات الاشتراك الحالي
  const subscription = await db.getSubscriptionByUserId(session.userId);
  const isSubscriptionActive = subscription && subscription.status === 'active';
  
  // تحديد تاريخ انتهاء الاشتراك إذا كان نشطًا
  let expiryDate = null;
  if (isSubscriptionActive && subscription.end_date) {
    expiryDate = new Date(subscription.end_date);
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">الاشتراك الشهري</h1>
        <div className="flex gap-4">
          <Link href="/dashboard">
            <Button variant="outline">العودة للوحة التحكم</Button>
          </Link>
        </div>
      </div>

      {isSubscriptionActive ? (
        <Card className="mb-8 bg-green-50">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <div>
                <h2 className="text-xl font-bold text-green-800">اشتراكك نشط</h2>
                <p className="text-green-700">
                  {expiryDate ? 
                    `ينتهي اشتراكك في ${expiryDate.toLocaleDateString('ar-EG')}` : 
                    'اشتراكك نشط حاليًا'}
                </p>
              </div>
              <div className="flex gap-2">
                <Link href="/dashboard">
                  <Button className="bg-green-600 hover:bg-green-700">استعراض المحتوى</Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="mb-8 bg-yellow-50">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <div>
                <h2 className="text-xl font-bold text-yellow-800">لا يوجد اشتراك نشط</h2>
                <p className="text-yellow-700">يرجى اختيار خطة اشتراك للوصول إلى المحتوى التعليمي</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-primary">
          <CardHeader>
            <CardTitle className="text-center">اشتراك شهري</CardTitle>
            <CardDescription className="text-center">الوصول لمدة شهر واحد</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-4xl font-bold">50 جنيه</p>
            <ul className="mt-4 space-y-2 text-right">
              <li>• الوصول إلى جميع الدروس</li>
              <li>• الوصول إلى جميع الاختبارات</li>
              <li>• دعم فني عبر البريد الإلكتروني</li>
            </ul>
          </CardContent>
          <CardFooter>
            <form action="/api/subscriptions/create" method="POST" className="w-full">
              <input type="hidden" name="plan" value="monthly" />
              <Button type="submit" className="w-full">اشترك الآن</Button>
            </form>
          </CardFooter>
        </Card>

        <Card className="border-primary bg-primary/5">
          <CardHeader>
            <div className="bg-primary text-primary-foreground py-1 px-3 rounded-full text-xs font-medium w-fit mx-auto">الأكثر شعبية</div>
            <CardTitle className="text-center mt-2">اشتراك فصلي</CardTitle>
            <CardDescription className="text-center">الوصول لمدة ثلاثة أشهر</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-4xl font-bold">120 جنيه</p>
            <p className="text-sm text-muted-foreground mt-1">توفير 30 جنيه</p>
            <ul className="mt-4 space-y-2 text-right">
              <li>• الوصول إلى جميع الدروس</li>
              <li>• الوصول إلى جميع الاختبارات</li>
              <li>• دعم فني عبر البريد الإلكتروني</li>
              <li>• تنزيل المحتوى للمشاهدة دون اتصال</li>
            </ul>
          </CardContent>
          <CardFooter>
            <form action="/api/subscriptions/create" method="POST" className="w-full">
              <input type="hidden" name="plan" value="quarterly" />
              <Button type="submit" className="w-full">اشترك الآن</Button>
            </form>
          </CardFooter>
        </Card>

        <Card className="border-primary">
          <CardHeader>
            <CardTitle className="text-center">اشتراك سنوي</CardTitle>
            <CardDescription className="text-center">الوصول لمدة عام كامل</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-4xl font-bold">450 جنيه</p>
            <p className="text-sm text-muted-foreground mt-1">توفير 150 جنيه</p>
            <ul className="mt-4 space-y-2 text-right">
              <li>• الوصول إلى جميع الدروس</li>
              <li>• الوصول إلى جميع الاختبارات</li>
              <li>• دعم فني عبر البريد الإلكتروني</li>
              <li>• تنزيل المحتوى للمشاهدة دون اتصال</li>
              <li>• جلسات مراجعة شخصية</li>
            </ul>
          </CardContent>
          <CardFooter>
            <form action="/api/subscriptions/create" method="POST" className="w-full">
              <input type="hidden" name="plan" value="yearly" />
              <Button type="submit" className="w-full">اشترك الآن</Button>
            </form>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
