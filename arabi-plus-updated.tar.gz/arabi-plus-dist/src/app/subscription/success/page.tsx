import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function SuccessPage() {
  return (
    <div className="container mx-auto p-6 flex items-center justify-center min-h-[80vh]">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-green-600">تم الاشتراك بنجاح!</CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <p className="mb-6">تم تفعيل اشتراكك بنجاح. يمكنك الآن الوصول إلى جميع المحتويات التعليمية في منصة عربي بلس.</p>
          <div className="flex flex-col gap-3">
            <Link href="/dashboard">
              <Button className="w-full">الذهاب إلى لوحة التحكم</Button>
            </Link>
            <Link href="/grades">
              <Button variant="outline" className="w-full">استعراض الصفوف الدراسية</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
