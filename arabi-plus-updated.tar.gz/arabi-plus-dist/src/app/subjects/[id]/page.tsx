import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireStudent } from "@/lib/auth";
import * as db from "@/lib/db";
import Link from "next/link";

export default async function SubjectPage({ params }: { params: { id: string } }) {
  // التحقق من صلاحيات الطالب
  const session = await requireStudent();
  
  // جلب بيانات الموضوع
  const subjectId = parseInt(params.id);
  const subject = await db.getSubjectById(subjectId);
  
  if (!subject) {
    return (
      <div className="container mx-auto p-6 text-center">
        <h1 className="text-3xl font-bold mb-4">الموضوع غير موجود</h1>
        <p className="mb-6">لم يتم العثور على الموضوع المطلوب</p>
        <Link href="/dashboard">
          <Button>العودة إلى لوحة التحكم</Button>
        </Link>
      </div>
    );
  }
  
  // جلب الدروس المرتبطة بالموضوع
  const lessonsResult = await db.getLessonsBySubjectId(subjectId);
  const lessons = lessonsResult?.results || [];
  
  // جلب بيانات الصف الدراسي
  const grade = await db.getGradeById(subject.grade_id);

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">{subject.name}</h1>
          <p className="text-gray-600">{subject.description || 'لا يوجد وصف متاح'}</p>
          {grade && (
            <p className="text-primary mt-1">
              <Link href={`/grades/${grade.id}`} className="hover:underline">
                {grade.name}
              </Link>
            </p>
          )}
        </div>
        <div className="flex gap-4">
          <Link href={`/grades/${subject.grade_id}`}>
            <Button variant="outline">العودة للصف الدراسي</Button>
          </Link>
        </div>
      </div>

      {lessons.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">لا توجد دروس متاحة حاليًا لهذا الموضوع</p>
            <p className="text-muted-foreground mt-2">يرجى التحقق لاحقًا</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {lessons.map((lesson) => (
            <Link key={lesson.id} href={`/lessons/${lesson.id}`}>
              <Card className="h-full hover:shadow-md transition-shadow cursor-pointer">
                <CardHeader>
                  <CardTitle>{lesson.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{lesson.description || 'لا يوجد وصف متاح'}</p>
                  <div className="flex items-center text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                      <polygon points="5 3 19 12 5 21 5 3"></polygon>
                    </svg>
                    <span>مشاهدة الدرس</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
