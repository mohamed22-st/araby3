import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { requireAdmin } from "@/lib/auth";
import * as db from "@/lib/db";
import Link from "next/link";

export default async function AdminDashboard() {
  // التحقق من صلاحيات المسؤول
  const session = await requireAdmin();
  
  // جلب بيانات الإحصائيات
  const studentsCountResult = await db.countStudents();
  const studentsCount = studentsCountResult?.count || 0;
  
  // جلب الصفوف الدراسية
  const gradesResult = await db.getAllGrades();
  const grades = gradesResult?.results || [];

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">لوحة تحكم المسؤول</h1>
        <div className="flex gap-4">
          <Link href="/admin/profile">
            <Button variant="outline">الملف الشخصي</Button>
          </Link>
          <form action="/api/auth/logout" method="POST">
            <Button variant="destructive" type="submit">تسجيل الخروج</Button>
          </form>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>إجمالي الطلاب</CardTitle>
            <CardDescription>عدد الطلاب المسجلين في المنصة</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">{studentsCount}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>الدروس</CardTitle>
            <CardDescription>إجمالي عدد الدروس المتاحة</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">0</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>الاختبارات</CardTitle>
            <CardDescription>إجمالي عدد الاختبارات المتاحة</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">0</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>إدارة المحتوى</CardTitle>
              <Link href="/admin/content/new">
                <Button>إضافة محتوى جديد</Button>
              </Link>
            </div>
            <CardDescription>إدارة المحتوى التعليمي للمنصة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Link href="/admin/content/videos" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <span className="ml-2">🎬</span> إدارة الفيديوهات
                </Button>
              </Link>
              <Link href="/admin/content/quizzes" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <span className="ml-2">📝</span> إدارة الاختبارات
                </Button>
              </Link>
              <Link href="/admin/content/subjects" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <span className="ml-2">📚</span> إدارة المواضيع
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>إدارة المستخدمين</CardTitle>
              <Link href="/admin/users/new">
                <Button>إضافة مستخدم جديد</Button>
              </Link>
            </div>
            <CardDescription>إدارة حسابات المستخدمين والاشتراكات</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Link href="/admin/users/students" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <span className="ml-2">👨‍🎓</span> إدارة الطلاب
                </Button>
              </Link>
              <Link href="/admin/users/subscriptions" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <span className="ml-2">💳</span> إدارة الاشتراكات
                </Button>
              </Link>
              <Link href="/admin/users/reports" className="block">
                <Button variant="outline" className="w-full justify-start">
                  <span className="ml-2">📊</span> تقارير المستخدمين
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>الصفوف الدراسية</CardTitle>
          <CardDescription>استعراض وإدارة المحتوى حسب الصف الدراسي</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {grades.map((grade) => (
              <Link key={grade.id} href={`/admin/grades/${grade.id}`}>
                <Button variant="outline" className="w-full h-24 flex flex-col items-center justify-center">
                  <span className="text-lg font-medium">{grade.name}</span>
                  <span className="text-sm text-muted-foreground">{grade.description}</span>
                </Button>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
