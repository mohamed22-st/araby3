import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireAdmin } from "@/lib/auth";
import * as db from "@/lib/db";
import Link from "next/link";

export default async function VideosListPage() {
  // التحقق من صلاحيات المسؤول
  await requireAdmin();
  
  // في بيئة حقيقية، سنقوم بجلب قائمة الفيديوهات من قاعدة البيانات
  // هنا نستخدم بيانات تجريبية للعرض
  const lessons = []; // سيتم استبدالها بنتائج استعلام قاعدة البيانات
  
  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">إدارة الفيديوهات</h1>
        <div className="flex gap-4">
          <Link href="/admin">
            <Button variant="outline">العودة للوحة التحكم</Button>
          </Link>
          <Link href="/admin/content/videos/new">
            <Button>رفع فيديو جديد</Button>
          </Link>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>الفيديوهات المرفوعة</CardTitle>
        </CardHeader>
        <CardContent>
          {lessons.length === 0 ? (
            <div className="text-center p-8">
              <p className="text-muted-foreground mb-4">لا توجد فيديوهات مرفوعة حاليًا</p>
              <Link href="/admin/content/videos/new">
                <Button>رفع فيديو جديد</Button>
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b">
                    <th className="py-3 px-4 text-right">العنوان</th>
                    <th className="py-3 px-4 text-right">الصف الدراسي</th>
                    <th className="py-3 px-4 text-right">الموضوع</th>
                    <th className="py-3 px-4 text-right">تاريخ الرفع</th>
                    <th className="py-3 px-4 text-right">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {lessons.map((lesson) => (
                    <tr key={lesson.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4">{lesson.title}</td>
                      <td className="py-3 px-4">{lesson.grade_name}</td>
                      <td className="py-3 px-4">{lesson.subject_name}</td>
                      <td className="py-3 px-4">{new Date(lesson.created_at).toLocaleDateString('ar-EG')}</td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <Link href={`/admin/content/videos/edit/${lesson.id}`}>
                            <Button variant="outline" size="sm">تعديل</Button>
                          </Link>
                          <form action={`/api/admin/videos/delete/${lesson.id}`} method="POST">
                            <Button variant="destructive" size="sm">حذف</Button>
                          </form>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
