import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireStudent } from "@/lib/auth";
import * as db from "@/lib/db";
import Link from "next/link";

export default async function GradePage({ params }: { params: { id: string } }) {
  // التحقق من صلاحيات الطالب
  const session = await requireStudent();
  
  // جلب بيانات الصف الدراسي
  const gradeId = parseInt(params.id);
  const grade = await db.getGradeById(gradeId);
  
  if (!grade) {
    return (
      <div className="container mx-auto p-6 text-center">
        <h1 className="text-3xl font-bold mb-4">الصف الدراسي غير موجود</h1>
        <p className="mb-6">لم يتم العثور على الصف الدراسي المطلوب</p>
        <Link href="/dashboard">
          <Button>العودة إلى لوحة التحكم</Button>
        </Link>
      </div>
    );
  }
  
  // جلب المواضيع المرتبطة بالصف الدراسي
  const subjectsResult = await db.getSubjectsByGradeId(gradeId);
  const subjects = subjectsResult?.results || [];

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">{grade.name}</h1>
          <p className="text-gray-600">{grade.description}</p>
        </div>
        <div className="flex gap-4">
          <Link href="/dashboard">
            <Button variant="outline">العودة للوحة التحكم</Button>
          </Link>
        </div>
      </div>

      {subjects.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">لا توجد مواضيع متاحة حاليًا لهذا الصف الدراسي</p>
            <p className="text-muted-foreground mt-2">يرجى التحقق لاحقًا</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((subject) => (
            <Link key={subject.id} href={`/subjects/${subject.id}`}>
              <Card className="h-full hover:shadow-md transition-shadow cursor-pointer">
                <CardHeader>
                  <CardTitle>{subject.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{subject.description || 'لا يوجد وصف متاح'}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
