import { NextRequest, NextResponse } from "next/server";
import * as db from "@/lib/db";
import { createSession, hashPassword, verifyPassword } from "@/lib/auth";

export async function POST(request: NextRequest) {
  try {
    // استلام بيانات تسجيل الدخول
    const formData = await request.formData();
    const username = formData.get('username') as string;
    const password = formData.get('password') as string;
    
    if (!username || !password) {
      return NextResponse.json(
        { error: 'يرجى إدخال اسم المستخدم وكلمة المرور' },
        { status: 400 }
      );
    }
    
    // البحث عن المستخدم في قاعدة البيانات
    const user = await db.getUserByUsername(username);
    
    if (!user) {
      return NextResponse.json(
        { error: 'اسم المستخدم أو كلمة المرور غير صحيحة' },
        { status: 401 }
      );
    }
    
    // التحقق من كلمة المرور
    const isPasswordValid = await verifyPassword(password, user.password);
    
    if (!isPasswordValid) {
      return NextResponse.json(
        { error: 'اسم المستخدم أو كلمة المرور غير صحيحة' },
        { status: 401 }
      );
    }
    
    // إنشاء جلسة جديدة
    await createSession(user.id, user.role);
    
    // إعادة توجيه المستخدم إلى الصفحة المناسبة
    const redirectUrl = user.role === 'admin' ? '/admin' : '/dashboard';
    
    return NextResponse.json(
      { success: true, redirectUrl },
      { status: 200 }
    );
    
  } catch (error) {
    console.error('خطأ في تسجيل الدخول:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء معالجة الطلب' },
      { status: 500 }
    );
  }
}
