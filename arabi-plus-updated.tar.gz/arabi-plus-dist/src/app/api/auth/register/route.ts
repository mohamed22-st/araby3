import { NextRequest, NextResponse } from "next/server";
import * as db from "@/lib/db";
import { createSession, hashPassword } from "@/lib/auth";

export async function POST(request: NextRequest) {
  try {
    // استلام بيانات التسجيل
    const formData = await request.formData();
    const username = formData.get('username') as string;
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    const confirmPassword = formData.get('confirm_password') as string;
    
    if (!username || !email || !password || !confirmPassword) {
      return NextResponse.json(
        { error: 'يرجى إكمال جميع الحقول المطلوبة' },
        { status: 400 }
      );
    }
    
    // التحقق من تطابق كلمات المرور
    if (password !== confirmPassword) {
      return NextResponse.json(
        { error: 'كلمات المرور غير متطابقة' },
        { status: 400 }
      );
    }
    
    // التحقق من عدم وجود مستخدم بنفس اسم المستخدم أو البريد الإلكتروني
    const existingUserByUsername = await db.getUserByUsername(username);
    if (existingUserByUsername) {
      return NextResponse.json(
        { error: 'اسم المستخدم مستخدم بالفعل' },
        { status: 400 }
      );
    }
    
    const existingUserByEmail = await db.getUserByEmail(email);
    if (existingUserByEmail) {
      return NextResponse.json(
        { error: 'البريد الإلكتروني مستخدم بالفعل' },
        { status: 400 }
      );
    }
    
    // تشفير كلمة المرور
    const hashedPassword = await hashPassword(password);
    
    // إنشاء المستخدم الجديد
    const user = await db.createUser(username, email, hashedPassword, 'student');
    
    if (!user) {
      return NextResponse.json(
        { error: 'فشل في إنشاء المستخدم' },
        { status: 500 }
      );
    }
    
    // إنشاء جلسة جديدة
    await createSession(user.id, 'student');
    
    return NextResponse.json(
      { success: true, redirectUrl: '/dashboard' },
      { status: 201 }
    );
    
  } catch (error) {
    console.error('خطأ في التسجيل:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء معالجة الطلب' },
      { status: 500 }
    );
  }
}
