import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import * as db from "@/lib/db";

// وظيفة مساعدة لتوليد اسم ملف فريد
function generateUniqueFileName(originalName: string): string {
  const timestamp = Date.now();
  const randomString = Math.random().toString(36).substring(2, 10);
  const extension = originalName.split('.').pop();
  return `${timestamp}-${randomString}.${extension}`;
}

export async function POST(request: NextRequest) {
  try {
    // التحقق من صلاحيات المسؤول
    const session = await requireAdmin();
    
    // استلام البيانات من النموذج
    const formData = await request.formData();
    const title = formData.get('title') as string;
    const description = formData.get('description') as string;
    const gradeId = parseInt(formData.get('grade_id') as string);
    const subjectName = formData.get('subject') as string;
    const videoFile = formData.get('video') as File;
    const thumbnailFile = formData.get('thumbnail') as File | null;
    
    if (!title || !gradeId || !subjectName || !videoFile) {
      return NextResponse.json(
        { error: 'جميع الحقول المطلوبة غير مكتملة' },
        { status: 400 }
      );
    }
    
    // التحقق من حجم الفيديو (500 ميجابايت كحد أقصى)
    const maxSize = 500 * 1024 * 1024; // 500 MB
    if (videoFile.size > maxSize) {
      return NextResponse.json(
        { error: 'حجم الفيديو يتجاوز الحد الأقصى المسموح به (500 ميجابايت)' },
        { status: 400 }
      );
    }
    
    // التحقق من نوع الفيديو
    const allowedTypes = ['video/mp4', 'video/webm'];
    if (!allowedTypes.includes(videoFile.type)) {
      return NextResponse.json(
        { error: 'صيغة الفيديو غير مدعومة. الصيغ المدعومة هي MP4 و WebM فقط' },
        { status: 400 }
      );
    }
    
    // معالجة الصورة المصغرة إذا تم تحميلها
    let thumbnailUrl = null;
    if (thumbnailFile) {
      const allowedImageTypes = ['image/jpeg', 'image/png', 'image/webp'];
      if (!allowedImageTypes.includes(thumbnailFile.type)) {
        return NextResponse.json(
          { error: 'صيغة الصورة المصغرة غير مدعومة. الصيغ المدعومة هي JPEG و PNG و WebP فقط' },
          { status: 400 }
        );
      }
      
      // توليد اسم فريد للصورة المصغرة
      const uniqueThumbnailName = generateUniqueFileName(thumbnailFile.name);
      thumbnailUrl = `/thumbnails/${uniqueThumbnailName}`;
      
      // في بيئة حقيقية، سيتم حفظ الصورة المصغرة هنا
      // مثال: await saveFileToStorage(thumbnailFile, thumbnailUrl);
    }
    
    // توليد اسم فريد للفيديو
    const uniqueVideoName = generateUniqueFileName(videoFile.name);
    const videoUrl = `/videos/${uniqueVideoName}`;
    
    // في بيئة حقيقية، سيتم حفظ الفيديو هنا
    // مثال: await saveFileToStorage(videoFile, videoUrl);
    
    // التحقق من وجود الموضوع أو إنشاء موضوع جديد
    let subject;
    const subjectsResult = await db.getSubjectsByGradeId(gradeId);
    const subjects = subjectsResult?.results || [];
    
    const existingSubject = subjects.find(s => s.name === subjectName);
    
    if (existingSubject) {
      subject = existingSubject;
    } else {
      // إنشاء موضوع جديد
      const newSubject = await db.createSubject(subjectName, null, gradeId);
      subject = newSubject;
    }
    
    if (!subject) {
      return NextResponse.json(
        { error: 'فشل في إنشاء الموضوع' },
        { status: 500 }
      );
    }
    
    // إنشاء درس جديد مع رابط الفيديو
    const lesson = await db.createLesson(title, description, videoUrl, subject.id);
    
    if (!lesson) {
      return NextResponse.json(
        { error: 'فشل في إنشاء الدرس' },
        { status: 500 }
      );
    }
    
    return NextResponse.json(
      { 
        success: true, 
        message: 'تم رفع الفيديو بنجاح', 
        lesson,
        videoUrl,
        thumbnailUrl
      },
      { status: 201 }
    );
    
  } catch (error) {
    console.error('خطأ في رفع الفيديو:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء معالجة الطلب' },
      { status: 500 }
    );
  }
}
