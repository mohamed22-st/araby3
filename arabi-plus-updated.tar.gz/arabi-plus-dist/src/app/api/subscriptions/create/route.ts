import { NextRequest, NextResponse } from "next/server";
import { requireStudent } from "@/lib/auth";
import * as db from "@/lib/db";

export async function POST(request: NextRequest) {
  try {
    // التحقق من صلاحيات الطالب
    const session = await requireStudent();
    
    // استلام بيانات الاشتراك
    const formData = await request.formData();
    const plan = formData.get('plan') as string;
    
    if (!plan || !['monthly', 'quarterly', 'yearly'].includes(plan)) {
      return NextResponse.json(
        { error: 'خطة الاشتراك غير صالحة' },
        { status: 400 }
      );
    }
    
    // حساب تاريخ انتهاء الاشتراك بناءً على الخطة
    const now = new Date();
    let endDate = new Date(now);
    
    switch (plan) {
      case 'monthly':
        endDate.setMonth(now.getMonth() + 1);
        break;
      case 'quarterly':
        endDate.setMonth(now.getMonth() + 3);
        break;
      case 'yearly':
        endDate.setFullYear(now.getFullYear() + 1);
        break;
    }
    
    // في بيئة حقيقية، هنا سيتم معالجة الدفع
    // مثال: const paymentResult = await processPayment(session.userId, plan);
    
    // إنشاء اشتراك جديد في قاعدة البيانات
    const subscription = await db.createSubscription(
      session.userId,
      endDate.toISOString(),
      'active'
    );
    
    if (!subscription) {
      return NextResponse.json(
        { error: 'فشل في إنشاء الاشتراك' },
        { status: 500 }
      );
    }
    
    // إعادة توجيه المستخدم إلى صفحة تأكيد الاشتراك
    return NextResponse.json(
      { 
        success: true, 
        message: 'تم إنشاء الاشتراك بنجاح',
        subscription,
        redirectUrl: '/subscription/success'
      },
      { status: 201 }
    );
    
  } catch (error) {
    console.error('خطأ في إنشاء الاشتراك:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء معالجة الطلب' },
      { status: 500 }
    );
  }
}
