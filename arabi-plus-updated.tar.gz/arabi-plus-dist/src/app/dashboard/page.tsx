import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { requireStudent } from "@/lib/auth";
import * as db from "@/lib/db";
import Link from "next/link";

export default async function StudentDashboard() {
  // التحقق من صلاحيات الطالب
  const session = await requireStudent();
  
  // جلب بيانات الطالب
  const user = session.user;
  
  // جلب الصفوف الدراسية
  const gradesResult = await db.getAllGrades();
  const grades = gradesResult?.results || [];

  // جلب بيانات الاشتراك
  const subscription = await db.getSubscriptionByUserId(session.userId);
  const isSubscriptionActive = subscription && subscription.status === 'active';

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">منصة عربي بلس</h1>
        <div className="flex gap-4">
          <Link href="/profile">
            <Button variant="outline">الملف الشخصي</Button>
          </Link>
          <form action="/api/auth/logout" method="POST">
            <Button variant="destructive" type="submit">تسجيل الخروج</Button>
          </form>
        </div>
      </div>

      {!isSubscriptionActive && (
        <Card className="mb-8 bg-yellow-50">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <div>
                <h2 className="text-xl font-bold text-yellow-800">لم يتم تفعيل الاشتراك</h2>
                <p className="text-yellow-700">يرجى تفعيل اشتراكك للوصول إلى جميع المحتويات التعليمية</p>
              </div>
              <Link href="/subscription">
                <Button className="bg-yellow-600 hover:bg-yellow-700">تفعيل الاشتراك الآن</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>آخر الدروس المضافة</CardTitle>
            <CardDescription>أحدث الدروس المتاحة في المنصة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center p-8 text-muted-foreground">
              لا توجد دروس متاحة حاليًا
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>تقدمك التعليمي</CardTitle>
            <CardDescription>متابعة تقدمك في المنصة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center p-8 text-muted-foreground">
              لم تكمل أي دروس بعد
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>الصفوف الدراسية</CardTitle>
          <CardDescription>استعرض المحتوى التعليمي حسب الصف الدراسي</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {grades.map((grade) => (
              <Link key={grade.id} href={`/grades/${grade.id}`}>
                <Button variant="outline" className="w-full h-24 flex flex-col items-center justify-center">
                  <span className="text-lg font-medium">{grade.name}</span>
                  <span className="text-sm text-muted-foreground">{grade.description}</span>
                </Button>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
